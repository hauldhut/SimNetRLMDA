import pandas as pd
import numpy as np
import os

# === Paths ===
DATA_DIR = "../Data/"

miRNANet = "miRNANetWSB"
print(f"miRNANet: {miRNANet}")

OUT_DIR = f"./data_{miRNANet}"

disease_files = {
    "d_ss.csv": "DiseaseSimNet_OMIM.txt"   # pre-defined disease similarity
}

mirna_files = {
    "c_ss.csv": f"{miRNANet}.txt"           # pre-defined miRNA similarity
}

# association file
assoc_file = "../Data/Phenotype2miRNAs_HMDD.csv"
# assoc_file = "/Users/hauldhut/Data/miRNA/HMDD/miRNA2Disease_HMDD_OMIM_final.csv"

# === Step 1: Load association file ===
assoc = pd.read_csv(assoc_file)
all_diseases = set(assoc["disease"])
all_mirnas = set(assoc["miRNA"])
print(f"all_diseases: {len(all_diseases)}")
print(f"all_mirnas: {len(all_mirnas)}")

# === Step 2: Load similarity networks ===
def load_network(filepath):
    df = pd.read_csv(filepath, sep="\t", header=None, names=["id1", "sim", "id2"])
    return df

disease_sets = []
for f in disease_files.values():
    df = load_network(os.path.join(DATA_DIR, f))
    disease_sets.append(set(df["id1"]).union(df["id2"]))
print(f"disease_sets: {len(set.intersection(*disease_sets))}")

mirna_sets = []
for f in mirna_files.values():
    df = load_network(os.path.join(DATA_DIR, f))
    mirna_sets.append(set(df["id1"]).union(df["id2"]))
print(f"mirna_sets: {len(set.intersection(*mirna_sets))}")

# === Step 3: Shared sets ===
shared_diseases = set.intersection(all_diseases, *disease_sets)
shared_mirnas = set.intersection(all_mirnas, *mirna_sets)
print(f"shared_diseases: {len(shared_diseases)}")
print(f"shared_mirnas: {len(shared_mirnas)}")

# === Step 4: Create index files ===
d_index = pd.DataFrame({"index": range(1, len(shared_diseases) + 1),
                        "disease": sorted(shared_diseases)})
d_index.to_csv(os.path.join(OUT_DIR, "d_index.csv"), index=False, header=False)

m_index = pd.DataFrame({"index": range(1, len(shared_mirnas) + 1),
                        "miRNA": sorted(shared_mirnas)})
m_index.to_csv(os.path.join(OUT_DIR, "m_index.csv"), index=False, header=False)

# lookup dicts
d_order = list(d_index["disease"])
m_order = list(m_index["miRNA"])
d2idx = {d: i for i, d in enumerate(d_order)}
m2idx = {m: i for i, m in enumerate(m_order)}

# === Step 5: Build disease similarity matrices (d_ss.csv) ===
def build_matrix(df, ids, fname, idx_dict):
    n = len(ids)
    mat = np.zeros((n, n))
    for _, row in df.iterrows():
        if row["id1"] in idx_dict and row["id2"] in idx_dict:
            i, j = idx_dict[row["id1"]], idx_dict[row["id2"]]
            mat[i, j] = row["sim"]
            mat[j, i] = row["sim"]  # symmetric
    np.savetxt(os.path.join(OUT_DIR, fname), mat, fmt="%.6f", delimiter=",")

for outname, fname in disease_files.items():
    df = load_network(os.path.join(DATA_DIR, fname))
    build_matrix(df, d_order, outname, d2idx)

# === Step 6: Build miRNA similarity matrices (c_ss.csv) ===
for outname, fname in mirna_files.items():
    df = load_network(os.path.join(DATA_DIR, fname))
    build_matrix(df, m_order, outname, m2idx)

# === Step 7: Build c_d.csv ===
m_d_mat = np.zeros((len(m_order), len(d_order)), dtype=int)
for _, row in assoc.iterrows():
    if row["miRNA"] in m2idx and row["disease"] in d2idx:
        i = m2idx[row["miRNA"]]
        j = d2idx[row["disease"]]
        m_d_mat[i, j] = 1

np.savetxt(os.path.join(OUT_DIR, "c_d.csv"), m_d_mat, fmt="%d", delimiter=",")

# === Step 8: Gaussian Interaction Profile kernel similarities (d_gs.csv, c_gs.csv) ===
def gip_kernel(matrix, axis=0):
    """
    Compute Gaussian Interaction Profile kernel similarity.
    axis=0 → kernel for rows (miRNAs)
    axis=1 → kernel for columns (diseases)
    """
    if axis == 1:  # diseases
        matrix = matrix.T

    n = matrix.shape[0]
    norms = np.linalg.norm(matrix, axis=1) ** 2
    gamma = 1 / np.mean(norms) if np.mean(norms) > 0 else 1.0

    K = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            diff = matrix[i] - matrix[j]
            K[i, j] = np.exp(-gamma * np.dot(diff, diff))
    return K

# Disease GIP similarity
d_gs = gip_kernel(m_d_mat, axis=1)
np.savetxt(os.path.join(OUT_DIR, "d_gs.csv"), d_gs, fmt="%.6f", delimiter=",")

# miRNA GIP similarity
c_gs = gip_kernel(m_d_mat, axis=0)
np.savetxt(os.path.join(OUT_DIR, "c_gs.csv"), c_gs, fmt="%.6f", delimiter=",")

# === Step 9: Create adjacency list ===
rows = []
for i, mirna in enumerate(m_order, 1):  # indices start at 1
    for j, disease in enumerate(d_order, 1):
        rows.append([i, j, m_d_mat[i-1, j-1]])

adj_df = pd.DataFrame(rows)
adj_df.to_csv(os.path.join(OUT_DIR, "all_md_pairs.csv"),
              index=False, header=False)

print("All files generated successfully (d_ss, c_ss, d_gs, c_gs, c_d, all_md_pairs).")
